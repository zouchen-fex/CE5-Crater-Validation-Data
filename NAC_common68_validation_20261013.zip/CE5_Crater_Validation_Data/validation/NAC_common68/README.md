# CE-5 NAC common 68 crater validation data

This local review bundle contains the latest common 68-crater cohort. Reference ID 1505 is excluded because not all primary NAC morphometric references are valid. Selection is based on reference availability, not on measured error.

GeoPackage contains full attributes; SHP contains compact identification and depth fields. Boundaries are preserved predicted catalog circles, not independently traced NAC rims. truth_id and src_row link the spatial data to selected_68_craters.csv and per_crater_common68.csv.

D_m, d_ours_m, d_nac_m and d_abs_m are in metres; lon/lat are lunar degrees. src_row is the recorded original CSV row identifier. IoU is dimensionless. For the publication table, volume is in 10^6 projected m3 and inclination is in degrees. Relative errors use positive reference values; their sample sizes may be smaller than 68.

The DTM is a 5 m Mons Rumker mosaic covering part of the CE-5 study region. Download the original raster from the official links in metadata.json. The large raster and all analysis/extraction code are excluded from this data-only bundle.
